using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Thing3D : Entity3D
{
}
