using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//This is on hand
public class CameraRotation : MonoBehaviour
{
    Vector2 mouselook;
    Vector2 smoothV;

    public float sencitivity = 5.0f;
    public float smoothing = 2.0f;

    GameObject target;

    // Use this for initialization
    void Start()
    {
        target = transform.root.gameObject;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector2 md = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));

        md = Vector2.Scale(md, new Vector2(sencitivity * smoothing, sencitivity * smoothing));
        smoothV.x = Mathf.Lerp(smoothV.x, md.x, 1f / smoothing);
        smoothV.y = Mathf.Lerp(smoothV.y, md.y, 1f / smoothing);
        mouselook += smoothV;
        mouselook.y = Mathf.Clamp(mouselook.y, -90f, 90f);

        transform.localRotation = Quaternion.AngleAxis(-mouselook.y, Vector3.right);

        //Parent rotation
        target.transform.Rotate(Vector3.up * Input.GetAxis("Mouse X") * sencitivity);
    }
}
