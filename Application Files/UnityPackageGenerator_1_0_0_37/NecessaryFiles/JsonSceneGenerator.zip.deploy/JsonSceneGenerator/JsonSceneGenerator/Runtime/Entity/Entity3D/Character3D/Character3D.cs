using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character3D : Entity3D
{
}
