using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character2D : Entity2D
{
}
