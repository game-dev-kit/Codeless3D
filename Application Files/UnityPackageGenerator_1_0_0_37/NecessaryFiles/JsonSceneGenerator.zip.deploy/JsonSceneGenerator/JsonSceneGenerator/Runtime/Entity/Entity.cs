using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour, iTakeDamage
{
    public float maxHealth;
    public bool takesDamage;
    float health;

    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
    }

    public void TakeDamage(float damage)
    {
        if (takesDamage)
        {
            health -= damage;
            if (health <= 0)
                print("Destroyed");
        }
        else
            print("invinsible");
    }
}
