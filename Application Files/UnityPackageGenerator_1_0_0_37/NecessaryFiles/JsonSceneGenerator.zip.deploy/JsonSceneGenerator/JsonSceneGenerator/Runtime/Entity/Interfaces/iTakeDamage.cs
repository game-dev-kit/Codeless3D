public interface iTakeDamage
{
    void TakeDamage(float damage);
}
