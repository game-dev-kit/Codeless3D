﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCollision : MonoBehaviour
{
    [SerializeField] int cameraBackDistance = 3;

    Transform steadyCameraPoint;
    Transform steadyPlayerPoint;

    private void Start()
    {
        steadyCameraPoint = transform.root.GetComponentInChildren<RotateCharacter>().transform;
        steadyPlayerPoint = transform.parent.parent.GetChild(1);
    }

    // Update is called once per frame
    void Update()
    {
        Ray rightRay = new Ray(transform.position, transform.right * 2);
        Debug.DrawRay(transform.position, transform.right * 2, Color.green);
        Ray leftRay = new Ray(transform.position, -transform.right * 2);
        Debug.DrawRay(transform.position, -transform.right * 2, Color.blue);
        Ray backRay = new Ray(steadyCameraPoint.position, -steadyCameraPoint.forward * (cameraBackDistance + 1));
        Debug.DrawRay(steadyCameraPoint.position, -steadyCameraPoint.forward * (cameraBackDistance + 1), Color.red);
        Ray stadyPlayerPointRay = new Ray(steadyPlayerPoint.position, transform.parent.transform.right * (cameraBackDistance + 1));
        Debug.DrawRay(steadyPlayerPoint.position, transform.parent.transform.right * (cameraBackDistance + 1), Color.magenta);

        Vector3 rightHitPoint;
        Vector3 leftHitPoint;
        Vector3 backHitPoint;
        Vector3 stadyPlayerPointHitPoint;
        float rightDistance;
        float leftDistance;
        float backDistance;
        float stadyPlayerPointDistance;

        FindClosestHitObject(rightRay, out rightHitPoint, out rightDistance);
        FindClosestHitObject(leftRay, out leftHitPoint, out leftDistance);
        FindClosestHitObject(backRay, out backHitPoint, out backDistance, ~(1 << 1));
        FindClosestHitObject(stadyPlayerPointRay, out stadyPlayerPointHitPoint, out stadyPlayerPointDistance);

        //If the ray hits somthing move camera to the hitpoint
        if (backDistance != 0 && backDistance <= cameraBackDistance)
            transform.position = backHitPoint;
        //Return the camera to the wanted position
        else
            transform.localPosition = new Vector3(0, 0, -cameraBackDistance);

        /* //If too close to a wall move stadyCameraPoint left
         if (stadyPlayerPointDistance > 0 && stadyPlayerPointDistance < 0.5)
             steadyCameraPoint.localPosition = stadyPlayerPointHitPoint;
         //Return the stadyCameraPoint to the wanted position
         else
             steadyCameraPoint.localPosition = new Vector3(0.4f, steadyCameraPoint.localPosition.y, 0);*/

        //If camera is too close to the player camera won't see the player Layer
        if (Vector3.Distance(transform.root.position, Camera.main.transform.position) < 2.5)
            Camera.main.cullingMask &= ~(1 << LayerMask.NameToLayer("TransparentFX"));
        else
            Camera.main.cullingMask = -1;
    }

    Transform FindClosestHitObject(Ray ray, out Vector3 hitPoint, out float distance, int layerMask = -1)
    {
        RaycastHit[] hits = Physics.RaycastAll(ray, 1000, layerMask);

        Transform closestHit = null;
        distance = 0;
        hitPoint = Vector3.zero;

        foreach (RaycastHit hit in hits)
        {
            if (hit.transform.root.tag != "Player" && hit.transform != transform && (closestHit == null || hit.distance < distance))
            {
                // We have hit something that is:
                // a) not us
                // b) the first thing we hit (that is not us)
                // c) or, if not b, is at least closer than the previous closest thing

                closestHit = hit.transform;
                distance = hit.distance;
                hitPoint = hit.point;
            }
        }

        // closestHit is now either still null (i.e. we hit nothing) OR it contains the closest thing that is a valid thing to hit

        return closestHit;
    }
}
