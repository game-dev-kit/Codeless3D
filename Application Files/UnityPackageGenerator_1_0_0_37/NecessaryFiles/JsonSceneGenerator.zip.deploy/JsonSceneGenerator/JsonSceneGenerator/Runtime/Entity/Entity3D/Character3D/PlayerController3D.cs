using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController3D : MonoBehaviour
{
    [SerializeField] float walkSpeed = 8;
    [SerializeField] float runSpeed = 12;
    [SerializeField] float jumpForce = 10;
    [SerializeField] LayerMask groundedMask = ~0;
    [SerializeField] float groundedRayLength = 0.2f;

    Rigidbody rb;

    //Vector3 moveAmount;
    //Vector3 smoothMoveVelocity;
    Vector3 moveVector;
    bool grounded;
    float speed;
    bool jumping;

    // Start is called before the first frame update
    void Start()
    {
        if (GetComponent<Rigidbody>())
            rb = GetComponent<Rigidbody>();
        else
            rb = gameObject.AddComponent<Rigidbody>();

        speed = walkSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        //Vector3 moveDir = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")).normalized;
        //Vector3 targetMoveAmount = moveDir * speed;
        //moveAmount = Vector3.SmoothDamp(moveAmount, targetMoveAmount, ref smoothMoveVelocity, .15f);

        Vector3 playerMovementInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical")).normalized;

        moveVector = transform.TransformDirection(playerMovementInput) * speed;

        if (Input.GetKeyDown(KeyCode.LeftShift))
            speed = runSpeed;
        else if (Input.GetKeyUp(KeyCode.LeftShift))
            speed = walkSpeed;

        if (grounded && Input.GetButtonDown("Jump"))
        {
            rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);

            jumping = true;
            Invoke(nameof(FinishedJumping), 1);
        }

        if (GetComponent<Animator>())
            if (jumping)
                GetComponent<Animator>().SetBool("Jumping", true);
            else
                GetComponent<Animator>().SetBool("Jumping", false);

        Ray groundedRay = new Ray(transform.position + new Vector3(0, 0.2f, 0), -transform.up);
        RaycastHit hit;

        if (groundedMask.value != 0)
        {
            if (Physics.Raycast(groundedRay, out hit, transform.localScale.y + groundedRayLength, groundedMask))
                grounded = true;
            else
                grounded = false;
        }
        else
        {
            if (Physics.Raycast(groundedRay, out hit, transform.localScale.y + groundedRayLength))
                grounded = true;
            else
                grounded = false;
        }

        if (GetComponent<Animator>())
            GetComponent<Animator>().SetFloat("Speed", rb.velocity.magnitude);
    }

    void FinishedJumping()
    {
        jumping = false;
    }

    private void FixedUpdate()
    {
        //rb.MovePosition(rb.position + transform.TransformDirection(moveAmount) * Time.fixedDeltaTime);
        rb.velocity = new Vector3(moveVector.x, rb.velocity.y, moveVector.z);
    }
}
