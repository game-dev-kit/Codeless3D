using LitJson;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityFBXExporter;

public class SceneExporterExecutor
{
    private static string sceneExportPath;
    private static JsonData jsonData;

    [MenuItem("Json Scene Generator/Export Scene")]
    public static void Execute()
    {
        sceneExportPath = EditorUtility.SaveFolderPanel(
            "Save Game Json",
            "",
            "");

        if (sceneExportPath != null && sceneExportPath != "" && EditorUtility.DisplayDialog("Exporting Scene", "The export of the scene may take some time. \nPlease don't close the editor unitl the process is complete!", "Ok", "Cancel"))
        {
            Directory.CreateDirectory(sceneExportPath + "/ExportedScene");

            SaveProjectPropertiesIntoJson();
            SaveModelPropertiesIntoJson();
            SaveSceneJsonFile();
            ExportModelFiles();

            Debug.Log("Scene Exported Successfuly!");
        }
    }

    static void SaveProjectPropertiesIntoJson()
    {
        jsonData = new JsonData
        {
            ["projectProperties"] = new JsonData
            {
                ["dimension"] = SceneView.lastActiveSceneView.in2DMode ? "2d" : "3d"
            }
        };
    }

    static void SaveModelPropertiesIntoJson()
    {
        jsonData["gameObjects"] = new JsonData();

        foreach (GameObject go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
        {
            if (go.name != "Sun" && go.name != "Ground" && go.name != "Background" && !go.CompareTag("MainCamera"))
            {
                jsonData["gameObjects"][go.name] = new JsonData
                {
                    ["name"] = go.name,
                    ["position"] = new JsonData
                    {
                        ["x"] = go.transform.position.x.ToString(),
                        ["y"] = go.transform.position.y.ToString(),
                        ["z"] = go.transform.position.z.ToString()
                    },
                    ["rotation"] = new JsonData
                    {
                        ["x"] = go.transform.rotation.x.ToString(),
                        ["y"] = go.transform.rotation.y.ToString(),
                        ["z"] = go.transform.rotation.z.ToString()
                    },
                    ["scale"] = new JsonData
                    {
                        ["x"] = go.transform.lossyScale.x.ToString(),
                        ["y"] = go.transform.lossyScale.y.ToString(),
                        ["z"] = go.transform.lossyScale.z.ToString()
                    },
                    ["hasPhysics"] = go.GetComponentInChildren<Rigidbody>() || go.GetComponentInChildren<Rigidbody2D>() ? "true" : "false",
                    ["hasMainCamera"] = go.GetComponentInChildren<Camera>() && go.GetComponentInChildren<Camera>().CompareTag("MainCamera") ? "true" : "false",
                    ["cameraType"] = go.GetComponentInChildren<CameraCollision>() ? "thirdPerson" : "firstPerson",
                    ["isControllable"] = go.GetComponentInChildren<Character3D>() || go.GetComponentInChildren<Character2D>() || go.GetComponentInChildren<PlayerController3D>() || go.GetComponentInChildren<Character2D>() ? "true" : "false",
                    ["health"] = go.GetComponentInChildren<Entity>() ? go.GetComponentInChildren<Entity>().maxHealth.ToString() : "10",
                };
                if (go.GetComponentInChildren<Collider>())
                    jsonData["gameObjects"][go.name]["colliderType"] = go.GetComponentInChildren<Collider>().GetType().ToString().Split('.')[1];
                if (go.GetComponentInChildren<Collider2D>())
                    jsonData["gameObjects"][go.name]["colliderType"] = go.GetComponentInChildren<Collider2D>().GetType().ToString().Split('.')[1];
                if (go.GetComponentInChildren<Rigidbody>() && go.GetComponentInChildren<Rigidbody>().useGravity)
                    jsonData["gameObjects"][go.name]["hasGravity"] = "true";
                if (go.GetComponentInChildren<Rigidbody2D>() && go.GetComponentInChildren<Rigidbody2D>().gravityScale != 0)
                    jsonData["gameObjects"][go.name]["hasGravity"] = "true";
            }
        }
    }

    static void SaveSceneJsonFile()
    {
        JsonData json = JsonMapper.ToJson(jsonData);

        File.WriteAllText(sceneExportPath + "/ExportedScene/SceneJson.json", json.ToString());
    }

    static void ExportModelFiles()
    {
        foreach (GameObject go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects())
            if (go.name != "Sun" && go.name != "Ground" && go.name != "Background" && !go.CompareTag("MainCamera"))
                if (!go.GetComponentInChildren<SpriteRenderer>())
                    ExportModelFiles3D(go);
                else
                    ExportModelFiles2D(go);
    }

    static void ExportModelFiles3D(GameObject go)
    {
        Directory.CreateDirectory(sceneExportPath + "/ExportedScene/" + go.name);

        //Export model
        FBXExporter.ExportGameObjToFBX(go, sceneExportPath + "/ExportedScene/" + go.name + "/" + go.name + ".fbx", true, true);

        //Export animations
        Animator animator = go.GetComponent<Animator>();

        if (animator)
        {
            Directory.CreateDirectory(sceneExportPath + "/ExportedScene/" + go.name + "/Animations");

            foreach (AnimationClip animationClip in animator.runtimeAnimatorController.animationClips)
            {
                string animationClipPath = AssetDatabase.GetAssetPath(animationClip);
                File.Copy(animationClipPath, sceneExportPath + "/ExportedScene/" + go.name + "/Animations/" + Path.GetFileName(animationClipPath), true);
            }
        }
    }

    static void ExportModelFiles2D(GameObject go)
    {
        Directory.CreateDirectory(sceneExportPath + "/ExportedScene/" + go.name);

        //Export model
        string texturePath = AssetDatabase.GetAssetPath(go.GetComponent<SpriteRenderer>().sprite.texture);
        File.Copy(texturePath, sceneExportPath + "/ExportedScene/" + go.name + "/" + Path.GetFileName(texturePath), true);

        //Export animations
        Animator animator = go.GetComponent<Animator>();

        if (animator)
        {
            Directory.CreateDirectory(sceneExportPath + "/ExportedScene/" + go.name + "/Animations");

            foreach (AnimationClip animationClip in animator.runtimeAnimatorController.animationClips)
            {
                Directory.CreateDirectory(sceneExportPath + "/ExportedScene/" + go.name + "/Animations/" + animationClip.name);

                foreach (Sprite animationKeyFrameSprite in GetSpritesFromClip(animationClip))
                {
                    string animationsKeyFrameSpritePath = AssetDatabase.GetAssetPath(animationKeyFrameSprite.texture);
                    File.Copy(animationsKeyFrameSpritePath, sceneExportPath + "/ExportedScene/" + go.name + "/Animations/" + animationClip.name + "/" + Path.GetFileName(animationsKeyFrameSpritePath), true);
                }
            }
        }
    }

    public static List<Sprite> GetSpritesFromClip(AnimationClip animationClip)
    {
        List<Sprite> sprites = new List<Sprite>();
        if (animationClip != null)
            foreach (EditorCurveBinding binding in AnimationUtility.GetObjectReferenceCurveBindings(animationClip))
            {
                ObjectReferenceKeyframe[] keyframes = AnimationUtility.GetObjectReferenceCurve(animationClip, binding);
                foreach (ObjectReferenceKeyframe frame in keyframes)
                    sprites.Add((Sprite)frame.value);
            }

        return sprites;
    }

    [MenuItem("Test/ExportRun")]
    static void ExportTest()
    {

    }
}
