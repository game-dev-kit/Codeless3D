using LitJson;
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityFBXExporter;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;

public abstract class SceneImporter
{
    protected string jsonString;
    protected JsonData jsonData;
    protected JsonData projectProperties;

    protected CultureInfo ci = (CultureInfo)CultureInfo.CurrentCulture.Clone();

    public SceneImporter()
    {
        //Set up float.Parse() to corectly parse decimal numbers
        ci.NumberFormat.NumberDecimalSeparator = ".";

        jsonString = File.ReadAllText("Packages/com.sleepydevs.json_scene_generator/Json/SceneJson.json");
        //Convert Json into Object
        jsonData = JsonMapper.ToObject(jsonString);
        //The general details of the project contained in Json
        projectProperties = jsonData["projectProperties"];

        ClearScene();
        SpawnObjects();
    }

    //Clear all previously instantiated GameObjects in the scene
    protected void ClearScene()
    {
        var sceneGameObjects = GameObject.FindObjectsOfType<GameObject>();
        foreach (GameObject go in sceneGameObjects)
            UnityEngine.Object.DestroyImmediate(go);
    }

    //Begin spawning new GameObjects acording to Json
    protected virtual void SpawnObjects()
    {
        AddGround();
        AddModels();
    }

    protected abstract void AddGround();
    protected abstract void AddModels();
    protected abstract void AddAnimations(GameObject go);
    protected abstract void AddCamera(GameObject go, JsonData jsonDataModel);

    protected void AddComponents(GameObject go, JsonData jsonDataModel)
    {
        AddPhysics(go, jsonDataModel);
        AddCollider(go, jsonDataModel);
        AddBasicScripts(go, jsonDataModel);
    }

    protected abstract void AddPhysics(GameObject go, JsonData jsonDataModel);

    protected abstract void AddCollider(GameObject go, JsonData jsonDataModel);

    //Match Json collider type string to unity Type
    protected abstract Type ColliderTypeMap(string type);

    protected virtual void AddBasicScripts(GameObject go, JsonData jsonDataModel)
    {
        //Set the health of the GameObject
        if (jsonDataModel.Keys.Contains("health"))
        {
            go.GetComponent<Entity>().takesDamage = true;
            go.GetComponent<Entity>().maxHealth = float.Parse(jsonDataModel["health"].ToString(), ci);
        }
    }
}