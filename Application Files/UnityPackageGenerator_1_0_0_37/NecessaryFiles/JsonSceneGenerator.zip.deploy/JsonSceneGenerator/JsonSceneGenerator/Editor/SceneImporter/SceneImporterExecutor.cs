using LitJson;
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityFBXExporter;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using UnityEditor.Animations;

public class SceneImporterExecutor
{
    [MenuItem("Json Scene Generator/Import Scene")]
    public static void ExecuteScript()
    {
        string jsonString = File.ReadAllText("Packages/com.sleepydevs.json_scene_generator/Json/SceneJson.json");
        //Convert Json into Object
        JsonData jsonData = JsonMapper.ToObject(jsonString);
        //The general details of the project contained in Json
        JsonData projectProperties = jsonData["projectProperties"];
        string dimension = projectProperties["dimension"].ToString();

        SceneImporter createScene;
        if (dimension == "3d")
        {
            EditorSettings.defaultBehaviorMode = EditorBehaviorMode.Mode3D;
            SceneView.lastActiveSceneView.in2DMode = false;

            createScene = new SceneImporter3D();
        }
        else
        {
            EditorSettings.defaultBehaviorMode = EditorBehaviorMode.Mode2D;
            SceneView.lastActiveSceneView.in2DMode = true;

            createScene = new SceneImporter2D();
        }
    }

    [MenuItem("Test/ImportRun")]
    static void ImportTest()
    {

    }
}
