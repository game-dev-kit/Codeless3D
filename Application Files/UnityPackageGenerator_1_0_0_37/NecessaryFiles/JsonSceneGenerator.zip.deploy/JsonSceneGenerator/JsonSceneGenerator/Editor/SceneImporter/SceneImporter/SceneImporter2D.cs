using LitJson;
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityFBXExporter;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using UnityEditor.Animations;

public class SceneImporter2D : SceneImporter
{
    GameObject background;

    //Begin spawning new GameObjects acording to Json
    protected override void SpawnObjects()
    {
        AddBackground();
        base.SpawnObjects();
    }

    void AddBackground()
    {
        if (Resources.Load<Texture2D>("Prefabs/Prefabs2D/Background"))
        {
            Texture2D texture2D = Resources.Load<Texture2D>("Prefabs/Prefabs2D/Background");
            Sprite sprite = Sprite.Create(texture2D, new Rect(0, 0, texture2D.width, texture2D.height), new Vector2(0.5f, 0.5f));
            sprite.name = texture2D.name;

            background = new GameObject("Background");
            background.AddComponent<SpriteRenderer>().sprite = sprite;
            background.transform.position = new Vector3(0, 0, 1);
        }
    }

    protected override void AddGround()
    {
        if (Resources.Load<Texture2D>("Prefabs/Prefabs2D/Ground"))
        {
            //GameObject ground = new GameObject("Ground");
            //ground.AddComponent<SpriteRenderer>().sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
            //ground.transform.localScale = new Vector3(1000, 50, 1);
            //ground.transform.position = new Vector3(0, -(ground.GetComponent<SpriteRenderer>().bounds.extents.y / 1.5f + background.GetComponent<SpriteRenderer>().bounds.extents.y), -1);
            //ground.AddComponent<BoxCollider2D>().size = new Vector2(ground.GetComponent<BoxCollider2D>().size.x, 0.14f);
            //ground.AddComponent<Rigidbody2D>().gravityScale = 0;
            //ground.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeAll;
            //ground.GetComponent<SpriteRenderer>().color = new Color32(85, 29, 0, 255);

            Texture2D texture2D = Resources.Load<Texture2D>("Prefabs/Prefabs2D/Ground");
            Sprite sprite = Sprite.Create(texture2D, new Rect(0, 0, texture2D.width, texture2D.height), new Vector2(0.5f, 0.5f));
            sprite.name = texture2D.name;

            GameObject grounds = new GameObject("Grounds");
            GameObject ground;
            GameObject ground1;

            for (int i = 0; i < 5; i++)
            {
                ground = new GameObject("Ground");
                ground.transform.parent = grounds.transform;
                ground.AddComponent<SpriteRenderer>().sprite = sprite;
                ground.transform.localScale = new Vector2(0.3f, 0.3f);
                ground.transform.position = new Vector3(i * 5.6f, -(ground.GetComponent<SpriteRenderer>().bounds.extents.y / 1.5f + background.GetComponent<SpriteRenderer>().bounds.extents.y), -1);
                ground.AddComponent<BoxCollider2D>();
                ground.AddComponent<Rigidbody2D>().gravityScale = 0;
                ground.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeAll;

                if (i != 0)
                {
                    ground1 = new GameObject("Ground");
                    ground1.transform.parent = grounds.transform;
                    ground1.AddComponent<SpriteRenderer>().sprite = sprite;
                    ground1.transform.localScale = new Vector2(0.3f, 0.3f);
                    ground1.transform.position = new Vector3(-i * 5.6f, -(ground1.GetComponent<SpriteRenderer>().bounds.extents.y / 1.5f + background.GetComponent<SpriteRenderer>().bounds.extents.y), -1);
                    ground1.AddComponent<BoxCollider2D>();
                    ground1.AddComponent<Rigidbody2D>().gravityScale = 0;
                    ground1.GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeAll;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                ground = new GameObject("Ground");
                ground.transform.parent = grounds.transform;
                ground.AddComponent<SpriteRenderer>().sprite = sprite;
                ground.transform.localScale = new Vector2(0.3f, 0.3f);
                ground.transform.position = new Vector3(i * UnityEngine.Random.Range(1.6f, 5.6f), -(ground.GetComponent<SpriteRenderer>().bounds.extents.y / 1.5f + background.GetComponent<SpriteRenderer>().bounds.extents.y), -1);

                if (i != 0)
                {
                    ground1 = new GameObject("Ground");
                    ground1.transform.parent = grounds.transform;
                    ground1.AddComponent<SpriteRenderer>().sprite = sprite;
                    ground1.transform.localScale = new Vector2(0.3f, 0.3f);
                    ground1.transform.position = new Vector3(-i * UnityEngine.Random.Range(1.6f, 5.6f), -(ground1.GetComponent<SpriteRenderer>().bounds.extents.y / 1.5f + background.GetComponent<SpriteRenderer>().bounds.extents.y), -1);
                }
            }

            grounds.transform.localScale = new Vector3(1, 1.81f, 1);
            grounds.transform.position = new Vector3(0, 3.7f, 0);
        }
    }

    protected override void AddModels()
    {
        //Iterate through each model in Json
        foreach (string key in jsonData["gameObjects"].Keys)
        {
            JsonData jsonDataModel = jsonData["gameObjects"][key];
            GameObject go;
            string modelName = jsonDataModel["name"].ToString();

            Texture2D texture2D = Resources.Load<Texture2D>("GameObjects/" + modelName + "/Models/" + modelName);
            Sprite sprite = Sprite.Create(texture2D, new Rect(0, 0, texture2D.width, texture2D.height), new Vector2(0.5f, 0.5f));
            sprite.name = texture2D.name;

            go = new GameObject(modelName);
            go.AddComponent<SpriteRenderer>().sprite = sprite;

            //Set the layer of the player to TransparentFX (Because I can't add new layers via scripting. I may find a way to bypass that later)
            if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
            {
                go.layer = 1;
                foreach (Transform childTransform in go.GetComponentInChildren<Transform>())
                    childTransform.gameObject.layer = 1;
            }

            go.transform.position = jsonDataModel.Keys.Contains("position") ? new Vector3(float.Parse(jsonDataModel["position"]["x"].ToString(), ci), float.Parse(jsonDataModel["position"]["y"].ToString(), ci), float.Parse(jsonDataModel["position"]["z"].ToString(), ci)) : Vector3.zero;
            go.transform.eulerAngles = jsonDataModel.Keys.Contains("rotation") ? new Vector3(float.Parse(jsonDataModel["rotation"]["x"].ToString(), ci), float.Parse(jsonDataModel["rotation"]["y"].ToString(), ci), float.Parse(jsonDataModel["rotation"]["z"].ToString(), ci)) : Vector3.zero;
            go.transform.localScale = jsonDataModel.Keys.Contains("scale") ? new Vector3(float.Parse(jsonDataModel["scale"]["x"].ToString(), ci), float.Parse(jsonDataModel["scale"]["y"].ToString(), ci), float.Parse(jsonDataModel["scale"]["z"].ToString(), ci)) : go.transform.localScale;

            if (jsonDataModel.Keys.Contains("hasAnimations") && jsonDataModel["hasAnimations"].ToString() == "true")
                AddAnimations(go);
            if (jsonDataModel.Keys.Contains("hasMainCamera") && jsonDataModel["hasMainCamera"].ToString() == "true")
                AddCamera(go, jsonDataModel);
            AddComponents(go, jsonDataModel);
        }
    }

    //Replace generalAnimationController's animations with GameObjects animations
    protected override void AddAnimations(GameObject go)
    {
        Animator animator = go.AddComponent<Animator>();
        AnimatorController generalAnimationController = Resources.Load<AnimatorController>("Prefabs/AnimationController/GeneralAnimationController");

        animator.runtimeAnimatorController = generalAnimationController;

        AnimatorOverrideController animatorOverrideController = new AnimatorOverrideController(animator.runtimeAnimatorController);

        AnimationClipOverrides clipOverrides = new AnimationClipOverrides(animatorOverrideController.overridesCount);

        animatorOverrideController.GetOverrides(clipOverrides);

        AnimationClip idleAnimationClip = CreateAnimationClip(go, "Idle");
        clipOverrides["Idle"] = idleAnimationClip;
        AnimationClip walkingAnimationClip = CreateAnimationClip(go, "Walking");
        clipOverrides["Walking"] = walkingAnimationClip;
        AnimationClip runningAnimationClip = CreateAnimationClip(go, "Running");
        clipOverrides["Running"] = runningAnimationClip;
        AnimationClip jumpingAnimationClip = CreateAnimationClip(go, "Jumping");
        clipOverrides["Jumping"] = jumpingAnimationClip;

        animatorOverrideController.ApplyOverrides(clipOverrides);

        animator.runtimeAnimatorController = animatorOverrideController;
    }

    //Creates animation clip according to the animation images provided
    AnimationClip CreateAnimationClip(GameObject go, string animationName)
    {
        // load animation images
        Texture2D[] textures2D = Resources.LoadAll<Texture2D>("GameObjects/" + go.name + "/Animations/" + animationName);
        Sprite[] sprites = new Sprite[textures2D.Length];
        for (int i = 0; i < sprites.Length; i++)
        {
            sprites[i] = Sprite.Create(textures2D[i], new Rect(0, 0, textures2D[i].width, textures2D[i].height), new Vector2(0.5f, 0.5f));
            sprites[i].name = textures2D[i].name;
        }

        //Create animation clip
        AnimationClip animClip = new AnimationClip();
        animClip.name = animationName;
        animClip.frameRate = 25;   // FPS

        //Set LoopTime to true (Except of jumping animation)
        if (animationName != "Jumping")
        {
            AnimationClipSettings settings = AnimationUtility.GetAnimationClipSettings(animClip);
            settings.loopTime = true;
            AnimationUtility.SetAnimationClipSettings(animClip, settings);
        }

        //Create animationClip Curve of type SpriteRenderer
        EditorCurveBinding spriteBinding = new EditorCurveBinding();
        spriteBinding.type = typeof(SpriteRenderer);
        spriteBinding.path = "";
        spriteBinding.propertyName = "m_Sprite";

        //Create
        ObjectReferenceKeyframe[] spriteKeyFrames = new ObjectReferenceKeyframe[sprites.Length];
        for (int i = 0; i < (sprites.Length); i++)
        {
            spriteKeyFrames[i] = new ObjectReferenceKeyframe();
            spriteKeyFrames[i].time = i / 10f;
            spriteKeyFrames[i].value = sprites[i];
        }

        AnimationUtility.SetObjectReferenceCurve(animClip, spriteBinding, spriteKeyFrames);

        return animClip;
    }

    //Add camera only to the main character that is marked as "isControllable"
    protected override void AddCamera(GameObject go, JsonData jsonDataModel)
    {
        GameObject mainCamera = new GameObject("MainCamera");
        mainCamera.AddComponent<Camera>().tag = "MainCamera";
        mainCamera.GetComponent<Camera>().orthographic = true;
        //mainCamera.orthographicSize = background.GetComponent<SpriteRenderer>().bounds.size.y * Screen.height / Screen.width * 0.5f;
        mainCamera.transform.position = new Vector3(go.transform.position.x, go.transform.position.y, -200);
        mainCamera.transform.parent = go.transform;
    }

    protected override void AddPhysics(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("hasPhysics") && jsonDataModel["hasPhysics"].ToString() == "true")
        {
            go.AddComponent(typeof(Rigidbody2D));

            if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
                go.GetComponent<Rigidbody2D>().freezeRotation = true;

            if (jsonDataModel.Keys.Contains("hasGravity") && jsonDataModel["hasGravity"].ToString() == "false")
                go.GetComponent<Rigidbody2D>().gravityScale = 0;
        }
    }

    protected override void AddCollider(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("colliderType"))
            go.AddComponent(ColliderTypeMap(jsonDataModel["colliderType"].ToString()));
    }

    protected override Type ColliderTypeMap(string type)
    {
        string lowerType = type.ToLower();

        return lowerType switch
        {
            "boxcollider2d" => typeof(BoxCollider2D),
            "capsulecollider2d" => typeof(CapsuleCollider2D),
            "polygoncollider2d" => typeof(PolygonCollider2D),
            "circlecollider2d" => typeof(CircleCollider2D),
            "compositecollider2d" => typeof(CompositeCollider2D),
            _ => typeof(EdgeCollider2D)
        };
    }

    protected override void AddBasicScripts(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
        {
            //Attach basic character script
            go.AddComponent(typeof(Character2D));
            //Attach movement script
            go.AddComponent(typeof(PlayerController2D));
        }
        else
            //Attach basic thing script
            go.AddComponent(typeof(Thing2D));

        base.AddBasicScripts(go, jsonDataModel);
    }
}
