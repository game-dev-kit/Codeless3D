using LitJson;
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityFBXExporter;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using UnityEditor.Animations;

public class SceneImporter3D : SceneImporter
{
    //Begin spawning new GameObjects acording to Json
    protected override void SpawnObjects()
    {
        AddLighting();
        base.SpawnObjects();
    }

    //Add some lighting to the scene
    void AddLighting()
    {
        GameObject lightGameObject = new GameObject("Sun");
        lightGameObject.transform.eulerAngles = new Vector3(50, -30, 0);
        lightGameObject.AddComponent<Light>().type = LightType.Directional;
        lightGameObject.GetComponent<Light>().lightmapBakeType = LightmapBakeType.Mixed;
        lightGameObject.GetComponent<Light>().shadows = LightShadows.Soft;
    }

    protected override void AddGround()
    {
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(100, 0.1f, 100);
        ground.GetComponent<Renderer>().material = new Material(Shader.Find("Standard"));
        ground.GetComponent<Renderer>().sharedMaterial.color = new Color32(0, 0, 0, 255);
        ground.GetComponent<MeshCollider>().convex = true;
        ground.GetComponent<MeshRenderer>().material = (Material)Resources.Load("Prefabs/Prefabs3D/Ground/Materials/Grass");
    }

    protected override void AddModels()
    {
        //Iterate through each model in Json
        foreach (string key in jsonData["gameObjects"].Keys)
        {
            JsonData jsonDataModel = jsonData["gameObjects"][key];
            GameObject go;
            string modelName = jsonDataModel["name"].ToString();

            go = GameObject.Instantiate(Resources.Load<GameObject>("GameObjects/" + modelName + "/Models/" + modelName));
            go.name = modelName;

            //Create Materias
            //if (!AssetDatabase.IsValidFolder("Packages/com.sleepydevs.json_scene_generator/Resources/GameObjects/" + go.name + "/Materials"))
            CreateMaterials(go);

            //Set the layer of the player to TransparentFX (Because I can't add new layers via scripting. I may find a way to bypass that later)
            if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
            {
                go.layer = 1;
                foreach (Transform childTransform in go.GetComponentInChildren<Transform>())
                    childTransform.gameObject.layer = 1;
            }

            go.transform.position = jsonDataModel.Keys.Contains("position") ? new Vector3(float.Parse(jsonDataModel["position"]["x"].ToString(), ci), float.Parse(jsonDataModel["position"]["y"].ToString(), ci), float.Parse(jsonDataModel["position"]["z"].ToString(), ci)) : Vector3.zero;
            go.transform.eulerAngles = jsonDataModel.Keys.Contains("rotation") ? new Vector3(float.Parse(jsonDataModel["rotation"]["x"].ToString(), ci), float.Parse(jsonDataModel["rotation"]["y"].ToString(), ci), float.Parse(jsonDataModel["rotation"]["z"].ToString(), ci)) : Vector3.zero;
            go.transform.localScale = jsonDataModel.Keys.Contains("scale") ? new Vector3(float.Parse(jsonDataModel["scale"]["x"].ToString(), ci), float.Parse(jsonDataModel["scale"]["y"].ToString(), ci), float.Parse(jsonDataModel["scale"]["z"].ToString(), ci)) : go.transform.localScale;

            if (jsonDataModel.Keys.Contains("hasAnimations") && jsonDataModel["hasAnimations"].ToString() == "true")
                AddAnimations(go);
            if (jsonDataModel.Keys.Contains("hasMainCamera") && jsonDataModel["hasMainCamera"].ToString() == "true")
                AddCamera(go, jsonDataModel);
            AddComponents(go, jsonDataModel);
        }
    }

    void CreateMaterials(GameObject go)
    {
        //Get all texture paths that end with .jpg or .jpeg, etc, from Textures folder
        string[] textures = Directory.GetFiles("Packages/com.sleepydevs.json_scene_generator/Resources/GameObjects/" + go.name + "/" + "Textures", "*.*", SearchOption.AllDirectories)
            .Where(s => s.EndsWith(".jpg") || s.EndsWith(".jpeg") || s.EndsWith(".png")).ToArray();
        //Create an array with only the names of the textures in Textures folder
        string[] textureNames = new string[textures.Length];
        for (int i = 0; i < textureNames.Length; i++)
            textureNames[i] = Path.GetFileNameWithoutExtension(textures[i]);

        foreach (Transform tr in go.GetComponentsInChildren<Transform>())
            if (tr.GetComponent<Renderer>())
            {
                //Create material
                Material material = new Material(Shader.Find("Standard"));

                if (textureNames.Contains(tr.name) || textureNames.Contains(tr.name + "_Normal"))
                {
                    //Assign texture to material
                    if (textureNames.Contains(tr.name))
                        material.mainTexture = (Texture)AssetDatabase.LoadAssetAtPath(textures[Array.IndexOf(textureNames, tr.name)], typeof(Texture));
                    //Assign normal map to material
                    if (textureNames.Contains(tr.name + "_Normal"))
                    {
                        //Change normal texture type to normal map
                        string path = textures[Array.IndexOf(textureNames, tr.name + "_Normal")];
                        TextureImporter textureImporter = AssetImporter.GetAtPath(path) as TextureImporter;
                        textureImporter.textureType = TextureImporterType.NormalMap;
                        AssetDatabase.ImportAsset(path);

                        material.EnableKeyword("_NORMALMAP");
                        material.SetTexture("_BumpMap", (Texture)AssetDatabase.LoadAssetAtPath(textures[Array.IndexOf(textureNames, tr.name + "_Normal")], typeof(Texture)));
                    }

                    //Assign material to gameobject
                    tr.GetComponent<Renderer>().material = material;
                }
            }
    }

    //Replace generalAnimationController's animations with GameObjects animations
    protected override void AddAnimations(GameObject go)
    {
        Avatar avatar;
        AnimationClip idleAnimationClip = Resources.Load<AnimationClip>("GameObjects/" + go.name + "/Animations/Idle");
        avatar = Resources.Load<Avatar>("GameObjects/" + go.name + "/Animations/Idle");
        AnimationClip walkingAnimationClip = Resources.Load<AnimationClip>("GameObjects/" + go.name + "/Animations/Walking");
        avatar = Resources.Load<Avatar>("GameObjects/" + go.name + "/Animations/Walking");
        AnimationClip runningAnimationClip = Resources.Load<AnimationClip>("GameObjects/" + go.name + "/Animations/Running");
        avatar = Resources.Load<Avatar>("GameObjects/" + go.name + "/Animations/Running");
        AnimationClip jumpingAnimationClip = Resources.Load<AnimationClip>("GameObjects/" + go.name + "/Animations/Jumping");
        avatar = Resources.Load<Avatar>("GameObjects/" + go.name + "/Animations/Jumping");

        Animator animator = go.AddComponent<Animator>();
        AnimatorController generalAnimationController = Resources.Load<AnimatorController>("Prefabs/AnimationController/GeneralAnimationController");

        animator.runtimeAnimatorController = generalAnimationController;

        if (avatar)
            animator.avatar = avatar;

        AnimatorOverrideController animatorOverrideController = new AnimatorOverrideController(animator.runtimeAnimatorController);

        AnimationClipOverrides clipOverrides = new AnimationClipOverrides(animatorOverrideController.overridesCount);

        animatorOverrideController.GetOverrides(clipOverrides);

        clipOverrides["Idle"] = idleAnimationClip;
        clipOverrides["Walking"] = walkingAnimationClip;
        clipOverrides["Running"] = runningAnimationClip;
        clipOverrides["Jumping"] = jumpingAnimationClip;

        animatorOverrideController.ApplyOverrides(clipOverrides);

        animator.runtimeAnimatorController = animatorOverrideController;
    }

    //Add camera only to the main character that is marked as "isControllable"
    protected override void AddCamera(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("cameraType") && jsonDataModel["cameraType"].ToString() == "firstPerson")
        {
            GameObject firstPersonCamera = new GameObject("FirstPersonCamera");
            firstPersonCamera.transform.parent = go.transform;

            GameObject mainCamera = new GameObject("FirstPersonCamera");
            mainCamera.tag = "MainCamera";
            mainCamera.transform.SetPositionAndRotation(go.transform.position + new Vector3(0, GetCharacterHeight(go), 0), go.transform.rotation);
            mainCamera.transform.parent = firstPersonCamera.transform;
            mainCamera.AddComponent<Camera>().cullingMask = ~(1 << 1);
            mainCamera.AddComponent(typeof(CameraRotation));
        }
        else
        {
            GameObject thirdPersonCamera = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Prefabs3D/ThirdPersonCamera/ThirdPersonCamera"));
            thirdPersonCamera.name = "ThirdPersonCamera";
            thirdPersonCamera.transform.SetPositionAndRotation(go.transform.position + new Vector3(0, GetCharacterHeight(go) + 1, 0), go.transform.rotation);
            thirdPersonCamera.transform.parent = go.transform;
        }
    }

    float GetCharacterHeight(GameObject go)
    {
        bool hasBounds = false;
        Bounds bounds = new Bounds(Vector3.zero, Vector3.zero);
        for (int i = 0; i < go.transform.childCount; ++i)
        {
            Renderer childRenderer = go.transform.GetChild(i).GetComponent<Renderer>();
            if (childRenderer != null)
                if (hasBounds)
                    bounds.Encapsulate(childRenderer.bounds);
                else
                {
                    bounds = childRenderer.bounds;
                    hasBounds = true;
                }
        }

        return bounds.size.y;
    }

    protected override void AddPhysics(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("hasPhysics") && jsonDataModel["hasPhysics"].ToString() == "true")
            go.AddComponent(typeof(Rigidbody));

        if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
            go.GetComponent<Rigidbody>().freezeRotation = true;

        if (jsonDataModel.Keys.Contains("hadGravity") && jsonDataModel["hadGravity"].ToString() == "true")
            go.GetComponent<Rigidbody>().useGravity = false;
    }

    protected override void AddCollider(GameObject go, JsonData jsonDataModel)
    {
        if (go.GetComponentInChildren<MeshFilter>() == null || (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true"))
        {
            go.AddComponent(typeof(CapsuleCollider));
            FitColliderSizeToChildrenSize(go);
        }
        else
        {
            if (jsonDataModel.Keys.Contains("hasCollider") && jsonDataModel["hasCollider"].ToString() == "true" && jsonDataModel.Keys.Contains("colliderType"))
                if (go.GetComponent<MeshFilter>() != null)
                {
                    go.AddComponent(ColliderTypeMap(jsonDataModel["colliderType"].ToString()));

                    if (jsonDataModel["colliderType"].ToString() == "meshCollider" && go.GetComponent<Rigidbody>())
                        go.GetComponent<MeshCollider>().convex = true;
                }
                else
                    foreach (MeshFilter meshFilter in go.transform.GetComponentsInChildren<MeshFilter>())
                    {
                        GameObject child = meshFilter.transform.gameObject;

                        if (child.GetComponent<MeshFilter>() != null)
                        {
                            child.AddComponent(ColliderTypeMap(jsonDataModel["colliderType"].ToString()));

                            if (jsonDataModel["colliderType"].ToString() == "meshCollider" && go.GetComponent<Rigidbody>())
                                child.GetComponent<MeshCollider>().convex = true;
                        }
                    }
        }
    }

    //If the GameObject itself has no Mesh, the collider that will be given to it will be a capsule collider with size acording to it's chldren
    void FitColliderSizeToChildrenSize(GameObject go)
    {
        if (go.GetComponent<Collider>() is CapsuleCollider)
        {
            bool hasBounds = false;
            Bounds bounds = new Bounds(Vector3.zero, Vector3.zero);
            for (int i = 0; i < go.transform.childCount; ++i)
            {
                Renderer childRenderer = go.transform.GetChild(i).GetComponent<Renderer>();
                if (childRenderer != null)
                    if (hasBounds)
                        bounds.Encapsulate(childRenderer.bounds);
                    else
                    {
                        bounds = childRenderer.bounds;
                        hasBounds = true;
                    }
            }

            CapsuleCollider collider = (CapsuleCollider)go.GetComponent<Collider>();
            collider.center = bounds.center - go.transform.position;
            collider.height = bounds.size.y;
            collider.center = new Vector3(0, collider.center.y, 0);
        }
    }

    //Match Json collider type string to unity Type
    protected override Type ColliderTypeMap(string type)
    {
        string lowerType = type.ToLower();

        return lowerType switch
        {
            "boxcollider" => typeof(BoxCollider),
            "capsulecollider" => typeof(CapsuleCollider),
            "meshcollider" => typeof(MeshCollider),
            "spherecollider" => typeof(SphereCollider),
            "terraincollider" => typeof(TerrainCollider),
            _ => typeof(WheelCollider)
        };
    }

    protected override void AddBasicScripts(GameObject go, JsonData jsonDataModel)
    {
        if (jsonDataModel.Keys.Contains("isControllable") && jsonDataModel["isControllable"].ToString() == "true")
        {
            //Attach basic character script
            go.AddComponent(typeof(Character3D));
            //Attach movement script
            go.AddComponent(typeof(PlayerController3D));
        }
        else
            //Attach basic thing script
            go.AddComponent(typeof(Thing3D));

        base.AddBasicScripts(go, jsonDataModel);
    }
}
